package example;

public interface ILeak {
}